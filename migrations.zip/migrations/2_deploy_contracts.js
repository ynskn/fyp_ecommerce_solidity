var ItemMarket = artifacts.require("./ItemMarket.sol");
var TicketMarket = artifacts.require("./TicketMarket.sol");

module.exports = function(deployer) {
  deployer.deploy(ItemMarket);
  deployer.deploy(TicketMarket);

};